from warn.warn import *
# -*- coding: utf-8 -*-
def bnr():
 print (f"""
{ken}    ______   _______     _       ____    ____  
{kon}  .' ____ \ |_   __ \   / \     |_   \  /   _| 
{ken}  | (___ \_|  | |__) | / _ \      |   \/   |   
{kon}   _.____`.   |  ___/ / ___ \     | |\  /| |   
{ken}  | \____) | _| |_  _/ /   \ \_  _| |_\/_| |_  
{kon}   \______.'|_____||____| |____||_____||_____| 
{im}••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
{kun}[$] Author  : {kin}Tuan Vigoo
{kun}[$] Script  : {kin}Brutal Spam
{kun}[$] Github  : {kin}https://github.com/D1SP3Y
{kun}[$] Youtube : {kin}Nothing
{im}••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••""")
